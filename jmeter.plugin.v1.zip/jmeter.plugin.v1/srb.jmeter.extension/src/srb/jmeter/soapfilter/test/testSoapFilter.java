package srb.jmeter.soapfilter.test;


import java.nio.charset.StandardCharsets;

import javax.xml.transform.TransformerException;

import srb.jmeter.soapfilter.*;
import srb.rfe.firma.QrCode;
import srb.rfe.firma.SignXml;
import srb.util.SoapFilterUtil;

public class testSoapFilter {
	
	 private static String urlBaseConsulta = "http://fep.mef.gob.pa/consultaQrCode";

	 public static void main(String[] args) {

		 //testReemplazar();
		 //testFiltrarDeArchivoXml();
		 //testCData();
		 //testFiltrarDeArchivoSoap();
		 //testgetFacturaXml();
		 testaddFacturaYCData();
		 //testSignXmlSha2();
		 //testSignXmlSha2YQrCodeV0();
		 //testtransformarXmlDeArchivoConXslHaciaArchivo();
	 }
	 
	 public static void testtransformarXmlDeArchivoConXslHaciaArchivo() {
		 System.out.println(".. Probando..");
		 String pathXmlIn = "/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/rFe.xml";
		 String pathXsl = "/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/filtrarNodosOpcionales.1.0.xsl";
		 String pathOut = "/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/testSalida.xml";

		 boolean resultado = SoapFilterUtil.transformarXmlDeArchivoConXslHaciaArchivo(pathXmlIn, pathXsl, pathOut);
		 if (resultado) System.out.println("Ok."); else System.out.println("Error.");
	 }
	 
	 public static void testSignXmlSha2YQrCodeV0() {
		 String archivoCertificado 
		 	= "/home/santi/Documents/coding/netbeans/EnviarFE/src/archivos/representante_valido_1_test.p12";
		 String clave = "pki.gob.pa";
		 SignXml signXml = new SignXml();
		 QrCode qrCode = new QrCode();
		 SoapFilter sf = new SoapFilter();
			try {
				String rFeOriginal = 
						sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/rFe.xml",
								StandardCharsets.UTF_8);
				String rFeFiltrado = 
						sf.filtrarOpcionalesDeArchivo(rFeOriginal, 
						"/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/filtrarNodosOpcionales.1.0.xsl",
						"Signature|gNoFirm");
				String xmlFirmado = signXml.firmarXml(rFeFiltrado, archivoCertificado, clave);
				String xmlFirmadoYQrCode = qrCode.qrCodeV0(urlBaseConsulta,xmlFirmado);
				System.out.println("xmlFirmadoYQrCode = " + xmlFirmadoYQrCode);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
	 }
	 
	 public static void testSignXmlSha2() {
		 String archivoCertificado 
		 	= "/home/santi/Documents/coding/netbeans/EnviarFE/src/archivos/representante_valido_1_test.p12";
		 String clave = "pki.gob.pa";
		 
		 SignXml signXml = new SignXml();
		 SoapFilter sf = new SoapFilter();
			try {
				String rFeOriginal = 
						sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/rFe.xml",
								StandardCharsets.UTF_8);
				String rFeFiltrado = 
						sf.filtrarOpcionalesDeArchivo(rFeOriginal, 
						"/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/filtrarNodosOpcionales.1.0.xsl",
						"Signature|gNoFirm");
				String xmlFirmado = signXml.firmarXml(rFeFiltrado, archivoCertificado, clave);
				System.out.println("xmlFirmado = " + xmlFirmado);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
	 }
	 
	 public static void testaddFacturaYCData() {
		 String archivoCertificado 
		 	= "/home/santi/Documents/coding/netbeans/EnviarFE/src/archivos/representante_valido_1_test.p12";
		 String clave = "pki.gob.pa";
		 SoapFilter sf = new SoapFilter();
			try {
				String rSoap = 
						sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/soapin.xml",
								StandardCharsets.UTF_8);
				//System.out.println("soapIN = " + rSoap);
				//System.out.println("--------------");
				String rSoapSinCData = sf.stripCData(rSoap);
				String rFe = sf.getFacturaXml(rSoapSinCData, "rFE");
				//System.out.println("rFE = " + rFe);
				String rFeFirmada = sf.firmar(rFe, archivoCertificado, clave);
				//System.out.println("rFeFirmada = " + rFeFirmada);
				String rFeFirmadaYQrCode = sf.qrCodeV0(urlBaseConsulta,rFeFirmada);
				//System.out.println("rFeFirmadaYQrCode = " + rFeFirmadaYQrCode);
				String rSoapFinal = sf.addFacturaYCData(rSoapSinCData, "rFE", rFeFirmadaYQrCode);
				System.out.println("soapFinal = " + rSoapFinal);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	 }
	 
	 public static void testgetFacturaXml() {
		 SoapFilter sf = new SoapFilter();
			try {
				String rSoap = 
						sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/soapin.xml",
								StandardCharsets.UTF_8);
				String rFe = sf.getFacturaXml(rSoap, "rFE");
				System.out.println("ptyDE = " + rFe);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	 }
	 
	 public static void testCData() {
		 String soapOriginal, soapSinCData, soapMasCData = "";
		 SoapFilter sf = new SoapFilter();
			try {
				soapOriginal = 
						sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/soapin.xml",
								StandardCharsets.UTF_8);
				System.out.println("Original = " + soapOriginal);
				soapSinCData = sf.stripCData(soapOriginal);
				System.out.println("Sin CDATA = " + soapSinCData);
				soapMasCData = sf.addCData(soapSinCData, "ptyDE");
				System.out.println("CON CDATA = " + soapMasCData);
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	 
	 public static void testReemplazar() {
		 try {
		 SoapFilter sf = new SoapFilter();

         String soapOriginal = "<soap><body><dato>123</dato></body></soap>";
         
         String soapNuevo = sf.reemplazar(soapOriginal, "<dato>123</dato>", "<dato>abc</dato>");	
         System.out.println("Resultado = " + soapNuevo);
		 } catch(Exception e) {
			 e.printStackTrace();
			 System.out.println(e.getStackTrace());
			 
		 }
	 }
	 
	 public static void testFiltrarDeArchivoXml() {
		 

		 SoapFilter sf = new SoapFilter();
		try {
			String rFeOriginal = 
					sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/rFe.xml",
							StandardCharsets.UTF_8);
			rFeOriginal = sf.stripCData(rFeOriginal);
			System.out.println("soapOri = " + rFeOriginal);
			String rFeFiltrado = 
					sf.filtrarOpcionalesDeArchivo(rFeOriginal, 
					"/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/filtrarNodosOpcionales.1.0.xsl",
					"gTot|firmas");
			System.out.println("soapFilt = " + rFeFiltrado);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 
		 
	 }
	 
	 public static void testFiltrarDeArchivoSoap() {
		 

		SoapFilter sf = new SoapFilter();
		String camposARemover = "puntoEmision|firmas"; 
		System.out.println("camposARemover : " + camposARemover);
		try {
			String rFeOriginal = 
					sf.readFile("/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/soapin.xml",
							StandardCharsets.UTF_8);
			rFeOriginal = sf.stripCData(rFeOriginal);
			String rFeFiltrado = 
					sf.filtrarOpcionalesDeArchivo(rFeOriginal, 
					"/home/santi/eclipse-workspace/srb.jmeter.extension/archivos/filtrarNodosOpcionales.1.0.xsl",
					camposARemover);
			rFeOriginal = sf.addCData(rFeOriginal, "rFE");
			System.out.println("rFE = " + rFeFiltrado);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 
		 
	 }

}
