package srb.jmeter.soapfilter;


import java.io.IOException;


import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import srb.jmeter.soapfilter.test.testSoapFilter;
import srb.rfe.firma.QrCode;
import srb.rfe.firma.SignXml;
import srb.util.SoapFilterUtil;

public class SoapFilter {
	
	public String reemplazar(String valor, String cadena, String nuevaCadena) throws Exception {
		throw new Exception("Super error");
		
	}
	
	public String readFile(String path, Charset encoding) throws IOException 
			
	{
		 	  String lpath = testSoapFilter.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		 	  System.out.println("DEBUG SRB soapFilter.readFile: Path = " + lpath);
		 	  String stringFile = null;
			  
			try {
				byte[] encoded;
				encoded = Files.readAllBytes(Paths.get(path));
				stringFile = new String(encoded, encoding); 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			}
			  return stringFile;
	}
	/***
	 * Elimina de un string los valores CDATA (inicio y final)
	 * @param originalConCData
	 * @return
	 */
	public String stripCData(String originalConCData) {
		return originalConCData.replace("<![CDATA[", "").replace("]]>","");
										   
	}
	
	public String addFacturaYCData(String soapSinCData,String nombreNodo, String rFactura) {
		
		String soapconFacturaYCData = null;
		// Crear document (XML) desde string
		Document documento = SoapFilterUtil.DocumentFromString(soapSinCData);
        // reemplazar nodo padre con contenido incluyendo cdata
        Node nodo = documento.getElementsByTagName(nombreNodo).item(0);
        //String stringNodo = SoapFilterUtil.nodeToString(nodo.cloneNode(true));
        //System.out.println("Nodo " + stringNodo);
        Node nodoPadre = nodo.getParentNode();
        Node cdataNode = documento.createCDATASection(rFactura);
        nodoPadre.replaceChild(cdataNode,nodo);
        soapconFacturaYCData = SoapFilterUtil.getStringFromDocument(documento);
        return soapconFacturaYCData ;
	}
	
	public String addCData(String xmlSinCData,String nombreNodo) throws Exception {
		
		String conCData = null;
		// Crear document (XML) desde string
		Document documento = SoapFilterUtil.DocumentFromString(xmlSinCData);
        // reemplazar nodo padre con contenido incluyendo cdata
        Node nodo = documento.getElementsByTagName(nombreNodo).item(0);
        String stringNodo = SoapFilterUtil.nodeToString(nodo.cloneNode(true));
        System.out.println("Nodo " + stringNodo);
        Node nodoPadre = nodo.getParentNode();
        Node cdataNode = documento.createCDATASection(stringNodo);
        nodoPadre.replaceChild(cdataNode,nodo);
        conCData = SoapFilterUtil.getStringFromDocument(documento);
        return conCData ;
	}
	/***
	 * Recibe un mensaje SOAP y el xpath del nodo de la factura, filtra los CDATA 
	 * @param soapMessage
	 * @param nodoFactura
	 * @return el XML de la factura que viene en el mensaje SOAP
	 */
			
	public String getFacturaXml(String soapMessage, String nodoFactura) {
		
		String soapSinCData = stripCData(soapMessage);
		Document documento = SoapFilterUtil.DocumentFromString(soapSinCData);
        // reemplazar nodo padre con contenido incluyendo cdata
        Node nodo = documento.getElementsByTagName(nodoFactura).item(0);
        return SoapFilterUtil.nodeToString(nodo.cloneNode(true));
	}
	/***
	 * Recibe factura, el path del xslt que filtra los campos y los campos separados 
	 * de la forma: "campo1|campo2|Signature|gNoFirm"
	 * Nota: Reemplazar el string del xslt "camposAOmitir" por el parametro de entrada
	 * @param rFeOriginal
	 * @param xsltFileName
	 * @param pCamposAOmitir
	 * @return La factura ya filtrada
	 * @throws Exception 
	 * @throws TransformerException
	 */
	public String filtrarOpcionalesDeArchivo
			(String rFeOriginal, String xsltFileName, String pCamposAOmitir) throws Exception{
			String xsltString;
			try {
				xsltString = readFile(xsltFileName, StandardCharsets.UTF_8);
				//System.out.println("DEBUG SRB " + "xml " + rFeOriginal);
				//System.out.println("DEBUG SRB XSLT : Path = " + xsltFileName);
				String xsltStringConCamposOmitir = xsltString.replaceAll("camposAOmitir", pCamposAOmitir);
				//System.out.println("DEBUG SRB soapFilter.readFile: Path = " + xsltStringConCamposOmitir);
				//filtrarOpcionales(rFeOriginal, xsltStringConCamposOmitir, pCamposAOmitir);
				return SoapFilterUtil.transformarXmlConXslt(rFeOriginal, xsltStringConCamposOmitir);				
			} catch (IOException | TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			}

	} 
    /**
     * Aplica la transformacioin 
     * @param rFeOriginal
     * @param elXslt
     * @param pCamposAOmitir
     * @return
     * @throws TransformerException
     */
//	private String filtrarOpcionales(String rFeOriginal, String elXslt, String pCamposAOmitir) 
//			throws TransformerException {
//		String resultado = null;
//		
//		TransformerFactory transformerFactory = TransformerFactory.newInstance();
//		StreamSource xsltSource = new StreamSource(new StringReader(elXslt));
//		StreamSource xmlSource = new StreamSource(new StringReader(rFeOriginal));
//		Transformer xsltTransformer;
//			xsltTransformer = transformerFactory.newTransformer(xsltSource);
//		//xsltTransformer.setParameter("camposAOmitir", pCamposAOmitir);
//		//create a StringWriter for the output
//		StringWriter outWriter = new StringWriter();
//		StreamResult result = new StreamResult( outWriter );
//			xsltTransformer.transform(xmlSource, result);
//			resultado  = result.getWriter().toString();
//		return resultado;
//	}
	
	
	public String firmar(String rFactura, String pathCertificado,String claveCertificado) {
		
		
		SignXml signXml = new SignXml();
		String rFacturaFirmada = signXml.firmarXml(rFactura, pathCertificado, claveCertificado);
		return rFacturaFirmada;
	}
	
	public String qrCodeV0(String urlBase, String rFacturaFirmada) {
		
		// Codigo Para armar qrcode
		QrCode qrCode = new QrCode();
		String rFacturaFirmadayQrCode = qrCode.qrCodeV0(urlBase, rFacturaFirmada);
		return rFacturaFirmadayQrCode;
	}
	
	public String qrCode(String urlBase,String rFacturaFirmada, String codigoSeguridad) {
		
		// Codigo Para armar qrcode
		QrCode qrCode = new QrCode();
		String rFacturaFirmadayQrCode = qrCode.qrCode(urlBase, rFacturaFirmada, codigoSeguridad);
		return rFacturaFirmadayQrCode;
	}

}
