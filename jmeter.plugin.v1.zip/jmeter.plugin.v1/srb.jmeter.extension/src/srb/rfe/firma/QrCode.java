package srb.rfe.firma;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import srb.util.SoapFilterUtil;

public class QrCode {

	
	
	public String qrCodeV0(String urlBase, String xmlFirmado) {
		Document facturaXmlFirmada = SoapFilterUtil.DocumentFromString(xmlFirmado);
		
		String qrCodeString = getQrCodeStringV0(urlBase, facturaXmlFirmada);
		
		return getXmlFirmadoYQrCode(facturaXmlFirmada, qrCodeString);
		
		
	}
	public String qrCode(String urlBase, String xmlFirmado, String codigoSeguridad) {
		
		Document facturaXmlFirmada = SoapFilterUtil.DocumentFromString(xmlFirmado);
	
		String qrCodeString = getQrCodeString(urlBase, facturaXmlFirmada, codigoSeguridad);
		
		return getXmlFirmadoYQrCode(facturaXmlFirmada, qrCodeString);
		
	}
	
	private String getXmlFirmadoYQrCode(Document facturaXmlFirmada, String qrCodeString) {
		
		Node qrCodeStringNode = SoapFilterUtil.stringToNode(qrCodeString);

		Node firstDocImportedNode = facturaXmlFirmada.importNode(qrCodeStringNode, true);
		facturaXmlFirmada.getDocumentElement().appendChild(firstDocImportedNode);
		String xmlFirmadoYQrCode = SoapFilterUtil.getStringFromDocument(facturaXmlFirmada);
		return xmlFirmadoYQrCode;
		
		
	}
	
	private String getQrCodeStringV0(String urlBase, Document facturaXmlFirmada) {
		String qrCodeTag = "";
		try {
			XPathFactory xPathfactory = XPathFactory.newInstance();
			XPath xpath = xPathfactory.newXPath();
			//XPathExpression expr = ;
			String dId = (String) xpath.compile("/rFE/dId/text()").evaluate(facturaXmlFirmada, XPathConstants.STRING);
			String qrCode = urlBase + "?" + "cufe="+dId;
			qrCodeTag = getQrCodeTag(qrCode);
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return qrCodeTag;
	}

	private String getQrCodeString(String urlBase, Document facturaXmlFirmada, String codigoSeguridad) {
		
		return getFixedQrCode();
	}

	private String getQrCodeTag(String qrCode) {
		return "<gNoFirm>\n" + 
				"    <dQRCode>" + qrCode+
				"</dQRCode>\n" + 
				"  </gNoFirm>";
		
	}
	
	public String getFixedQrCode() {
		return "<gNoFirm>\n" + 
				"    <dQRCode>http://fepws.mef.gob.pa/consulta?cufe=1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890</dQRCode>\n" + 
				"  </gNoFirm>";
		
	}
}
