package srb.rfe.firma;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;


import srb.util.SoapFilterUtil;

public class SignXml {
	
	public String signXmlDummy(String xmlIn, String pathCertificado, String clave) {
		
		Document facturaXml = SoapFilterUtil.DocumentFromString(xmlIn);
		// reemplazar por la firma
		String signatureString = getFixedSignatureString();
		
		Node signatureNode = SoapFilterUtil.stringToNode(signatureString);
		Node firstDocImportedNode = facturaXml.importNode(signatureNode, true);
		facturaXml.getDocumentElement().appendChild(firstDocImportedNode);
		String xmlFirmado = SoapFilterUtil.getStringFromDocument(facturaXml);
		return xmlFirmado;
	}
	
	public String firmarXml(String xml, String archivoCertificado, String claveCertificado) {
		Document xmlDoc = SoapFilterUtil.DocumentFromString(xml);
		Document signedXmlDocument = firmarXmlDocument(xmlDoc, archivoCertificado,claveCertificado);
		String signedXml = SoapFilterUtil.getStringFromDocument(signedXmlDocument);
		//String signedXmlStripXmlDeclaration = signedXml;
		//		signedXml.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>", "");
		return signedXml;//signedXmlStripXmlDeclaration;
	}
	
    public Document firmarXmlDocument(Document docToSign, String archivoCertificado, String claveCertificado) {

        try {
            // Create a DOM XMLSignatureFactory that will be used to
            // generate the enveloped signature.
            XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

            // Create a Reference to the enveloped document (in this case,
            // you are signing the whole document, so a URI of "" signifies
            // that, and also specify the SHA1 digest algorithm and
            // the ENVELOPED Transform.
            Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA256, null),
                    Collections.singletonList(fac.newTransform(Transform.ENVELOPED,
                            (TransformParameterSpec) null)), null, null);
            
                            
            // Create the SignedInfo.
            SignedInfo si = fac.newSignedInfo(
                    fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
                            (C14NMethodParameterSpec) null),
                    fac.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256", null),
                    Collections.singletonList(ref));


            // Load the KeyStore and get the signing key and certificate.
            //KeyStore ks = KeyStore.getInstance("PKCS12");
            //ks.load(this.getClass().getClassLoader().getResourceAsStream(archivoCertificado), claveCertificado.toCharArray());
            KeyStore p12 = KeyStore.getInstance("pkcs12");
            p12.load(new FileInputStream(archivoCertificado), claveCertificado.toCharArray());
            KeyStore.PrivateKeyEntry keyEntry
                    = (KeyStore.PrivateKeyEntry) p12.getEntry("2", new KeyStore.PasswordProtection(claveCertificado.toCharArray()));

            System.out.println(" Size- " + p12.size());

            System.out.println("private keyEntry " + keyEntry.getPrivateKey().toString());

            X509Certificate cert = (X509Certificate) keyEntry.getCertificate();

            // Create the KeyInfo containing the X509Data.
            KeyInfoFactory kif = fac.getKeyInfoFactory();
            List x509Content = new ArrayList();
            x509Content.add(cert.getSubjectX500Principal().getName());
            x509Content.add(cert);
            X509Data xd = kif.newX509Data(x509Content);
            KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));

            // Create a DOMSignContext and specify the RSA PrivateKey and
            // location of the resulting XMLSignature's parent element.
            //DOMSignContext dsc = new DOMSignContext(keyEntry.getPrivateKey(), docToSign.getDocumentElement().getElementsByTagName("gDGen").item(0));
            DOMSignContext dsc = new DOMSignContext(keyEntry.getPrivateKey(), docToSign.getDocumentElement());
            
            // Create the XMLSignature, but don't sign it yet.
            javax.xml.crypto.dsig.XMLSignature signature = fac.newXMLSignature(si, ki);

            // Marshal, generate, and sign the enveloped signature.
            signature.sign(dsc);

        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        } catch (InvalidAlgorithmParameterException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (CertificateException ex) {
            ex.printStackTrace();
        } catch (KeyStoreException ex) {
            ex.printStackTrace();
        } catch (UnrecoverableEntryException ex) {
            ex.printStackTrace();
        } catch (MarshalException ex) {
            ex.printStackTrace();
        } catch (XMLSignatureException ex) {
            ex.printStackTrace();
        }
        return docToSign;
    }
	
	private String getFixedSignatureString() {
		
		return "<Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\">\n" + 
				"    <SignedInfo>\n" + 
				"      <CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-C24n-20010315\"/>\n" + 
				"      <SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>\n" + 
				"\n" + 
				"      <Reference URI=\"#FE01200023824-0930-21262328001201707150000151340010117450183430\">\n" + 
				"        <Transforms>\n" + 
				"          <Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/>\n" + 
				"          <Transform Algorithm=\"http://www.w3.org/TR/2001/REC-xml-C24n-20010315\"/>\n" + 
				"        </Transforms>\n" + 
				"\n" + 
				"        <DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"/>\n" + 
				"        <DigestValue>vFL68WETQ+mvj1aJAMDx+oVi928=</DigestValue>\n" + 
				"      </Reference>\n" + 
				"    </SignedInfo>\n" + 
				"\n" + 
				"    <SignatureValue>rDM8lP5IxIoEAIcsVcfBJXb+FcKYeGHAkS5S9yeLHNjZ45JtIrYbIvhp2YNqn+sTB0+MScVHe2HWjVv9wrEGqIBpnP1zzzLxJrxrEqOP/AxlDGeYPsydOUudnuBOWaC4wKd0sFfIgzrmq7dNKunB0eoKRvvEbweCT3NiyIHO1j8=</SignatureValue>\n" + 
				"\n" + 
				"    <KeyInfo>\n" + 
				"      <X509Data>\n" + 
				"        <X509Certificate>\n" + 
				"          IjCCBMowggQzoAMCAQICEAlLTA9Y1WjWPxvngISRWxQwDQYJKoZIhvcNAQEEBQAwgcwxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMUYwRAYDVQQLEz13d3cudmVyaXNpZ24uY29tL3JlcG9zaXRvcnkvUlBBIEluY29ycC4gQnkgUmVmLixMSUFCLkxURChjKTk4MUgwRgYDVQQDEz9WC2CGSAGG+EUBBwEBMIAwKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LnZlcmlzaWduLmNvbS9DUFMwYgYIKwYBBQUHAgIwVjAVFg5WZXJpU2lnbiwgSW5jLjADAgEBGj1WZXJpU2lnbidzIENQUyBpbmNvcnAuIGJ5IHJlZmVyZW5jZSBsaWFiLiBsdGQuIChjKTk3IFZlcmlTaWduAAAAAAAAMBEGCWCGSAGG+EIBAQQEAwIHgDCBhgYKYIZIAYb4RQEGAwR4FnZkNDY1MmJkNjNmMjA0NzAyOTI5ODc2M2M5ZDJmMjc1MDY5YzczNTliZWQxYjA1OWRhNzViYzRiYzk3MDE3NDdkYTVkM2YyMTQxYmVhZGIyYmQyZTg5MjFmYTU2YmY0ZDQxMTQ5OTdhM2I4NDNmNGU1OTI2NTQxMA0GCSqGSIb3DQEBBAUAA4GBAInZL/R7kMLBcunvA2KRxe+BE2i58wQBrlhtBk5kQ3oYSUsyjfEV3JiH/aBjC8QLNYx0vBUt2bcYTZtmPLlhepbBiNi8X/Ke+Pf8c4RVYDs43a7SDw3fmo1BAkPD1BeGES9KTr3VCeTcoLZTfB5ZCERqVMoriTB7jzCUMItNvoe3Ig0K\n" + 
				"        </X509Certificate>\n" + 
				"      </X509Data>\n" + 
				"    </KeyInfo>\n" + 
				"\n" + 
				"  </Signature>";
	}

}
