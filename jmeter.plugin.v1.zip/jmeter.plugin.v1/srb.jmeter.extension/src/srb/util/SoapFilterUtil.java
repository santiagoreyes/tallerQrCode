package srb.util;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public  class SoapFilterUtil {

	public static String getStringFromDocument(Document doc)
	{
	    try
	    {
	       DOMSource domSource = new DOMSource(doc);
	       StringWriter writer = new StringWriter();
	       StreamResult result = new StreamResult(writer);
	       TransformerFactory tf = TransformerFactory.newInstance();
	       Transformer transformer = tf.newTransformer();
	       transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	       transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	       transformer.transform(domSource, result);
	       return writer.toString();
	    }
	    catch(TransformerException ex)
	    {
	       ex.printStackTrace();
	       return null;
	    }
	} 
	
	public static Node stringToNode(String contenido) {
		Document doc = DocumentFromString(contenido);
		return doc.getFirstChild();
	}
	
	public static String nodeToString(Node node) {
	    StringWriter sw = new StringWriter();
	    try {
	      Transformer t = TransformerFactory.newInstance().newTransformer();
	      t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	      t.setOutputProperty(OutputKeys.INDENT, "yes");
	      t.transform(new DOMSource(node), new StreamResult(sw));
	    } catch (TransformerException te) {
	      System.out.println("nodeToString Transformer Exception");
	    }
	    return sw.toString();
	  }
	
	public static Document DocumentFromString(String stringXml) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db;
        Document document = null;
		try {
			db = dbf.newDocumentBuilder();
   		  document = db.parse(new InputSource(new StringReader(stringXml)));
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
        return document;
	}
	
	public static String transformarXmlConXslt(String rFeOriginal, String elXslt) 
			throws TransformerException {
		String resultado = null;
		//System.out.println("UTIL rFeOriginal= " + rFeOriginal);
		//System.out.println("----------------");
		//System.out.println("UTIL elXslt= " + elXslt);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		StreamSource xsltSource = new StreamSource(new StringReader(elXslt));
		StreamSource xmlSource = new StreamSource(new StringReader(rFeOriginal));
		Transformer xsltTransformer;
			xsltTransformer = transformerFactory.newTransformer(xsltSource);
		//xsltTransformer.setParameter("camposAOmitir", pCamposAOmitir);
		//create a StringWriter for the output
		StringWriter outWriter = new StringWriter();
		StreamResult result = new StreamResult( outWriter );
		//System.out.println("--------2--------");
			xsltTransformer.transform(xmlSource, result);
			resultado  = result.getWriter().toString();
		return resultado;
	}
	
	public static boolean transformarXmlDeArchivoConXslHaciaArchivo(
			String pathXmlIn,String pathXsl,  String pathOut) {
		
		try {
			TransformerFactory factory = TransformerFactory.newInstance();
			Source xslt = new StreamSource(new File(pathXsl));
			Transformer transformer = factory.newTransformer(xslt);
			Source xml = new StreamSource(new File(pathXmlIn));
			transformer.transform(xml, new StreamResult(new File(pathOut)));
			return true;
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
}
