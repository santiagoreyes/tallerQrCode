function inicializar() {
    var codigos = document.querySelectorAll(".qrcode");
    for (var i = 0, len = codigos.length; i < len; i++) {
        var qrcode = codigos[i].getAttribute("qrcode");
        generaQr(qrcode,codigos[i] );
    }
}

function generaQr(codigoQr, me){

        var qrcode = new QRCode(me, {
	        width : 100,
	        height : 100
        });
        me.innerHtml = qrcode.makeCode(codigoQr);
        me.style.textAlign = "center";
}


