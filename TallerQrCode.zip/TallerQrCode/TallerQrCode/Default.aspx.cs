﻿using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TallerQrCode
{
    public partial class _Default : System.Web.UI.Page
    {
        private string strImagenQrCode;
        private int version = 0;
        private string eccLevel = "";
        public string EccLevel { get { return eccLevel; } }
       
        public int Version { get { return version; } }
        public string StrImagenQrCode { get { return strImagenQrCode; } }
        protected void Page_Load(object sender, EventArgs e)
        {
            this.qrCode.Visible = false;
        }

        public string byteToString(byte[] byteImage){
            return Convert.ToBase64String(byteImage, 0, byteImage.Length);
        }

        public byte[] bitmapToByte(Bitmap imagen) {
            //return imagen.ToByteArray(ImageFormat.Bmp)
            using (var stream = new MemoryStream())
            {
                imagen.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }

        public Bitmap  generar(string texto, QRCodeGenerator.ECCLevel eclevel) {
            QRCodeGenerator qrGenerator = new QRCodeGenerator();

            QRCodeData qrCodeData = qrGenerator.CreateQrCode(texto, eclevel);
            this.version = qrCodeData.Version;
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);
            return qrCodeImage;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string lTexto = this.TextBox1.Text;
            string eccValor = DropDownList1.SelectedValue;

            QRCodeGenerator.ECCLevel lEccLevel =
                eccValor == "L" ? QRCodeGenerator.ECCLevel.L :
                (eccValor == "M"? QRCodeGenerator.ECCLevel.M : 
                (eccValor == "Q" ? QRCodeGenerator.ECCLevel.Q : QRCodeGenerator.ECCLevel.H));

            this.eccLevel = lEccLevel.ToString();
            this.qrCode.Visible = true;
            this.qrCode.Src = "data:image/png;base64," +byteToString(bitmapToByte(generar(lTexto, lEccLevel)));

        }
    }
}