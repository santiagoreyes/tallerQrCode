﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json.Linq;
using Microsoft.IdentityModel.Tokens;
using System.ServiceModel.Security.Tokens;

namespace TallerQrCode
{
    public partial class QrCodeFE : System.Web.UI.Page
    {
        private string generado;
        public string Generado { get { return generado; } }

        private string llave = "2eaba500949e4ca5aecc982c3a8d636b5a8ada9809a64a39848bb9e2b39f5d896fb29b80a2894051b9552494b94c518c64c6970ca4f84ed9a8be365b3daf9c9c";
        public string Llave { get { return llave; } }

        private string jsonLeido;
        public string JsonLeido { get { return jsonLeido; } }

        private string mensaje;
        public string Mensaje { get { return mensaje; } }

        private string decodificado;
        public string Decodificado { get { return decodificado; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
                this.mensaje = "";
                
            }
        }

        private string generar(string cadenaSeguridad, JArray pCampos)
        {

            var tokenHandler = new JwtSecurityTokenHandler();

            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(
                System.Text.Encoding.Default.GetBytes(cadenaSeguridad));

            var signingCredentials = 
                new Microsoft.IdentityModel.Tokens.SigningCredentials(
                    securityKey, 
                    Microsoft.IdentityModel.Tokens.SecurityAlgorithms.HmacSha256Signature);
            //  Crear el token header
            var header = new JwtHeader(signingCredentials);

            IEnumerable<Claim> listaClaims = generaClaimsList(pCampos);

            /*  Formato simple de campo valor
            JwtPayload payload = new JwtPayload
               {
                   { "cufe", "fe020202"},
                   { "ruc", "32839283892"},
               };
            */
            JwtPayload payload = new JwtPayload(listaClaims);
            
            

            var secToken = new JwtSecurityToken(header, payload);
            var handler = new JwtSecurityTokenHandler();

            // Token to String so you can use it in your client
            var tokenString = handler.WriteToken(secToken);

            return tokenString;

        }

        protected IEnumerable<Claim> generaClaimsList(JArray campos)
        {
            List<Claim> claimsList = new List<Claim>();
            foreach (JObject root in campos)
            {
                foreach (KeyValuePair<String, JToken> app in root)
                {
                    Claim claim = new Claim(app.Key, app.Value.ToString());
                    claimsList.Add(claim);
                }
            }

            return claimsList;
        }


        protected void btnGenerar_Click(object sender, EventArgs e)
        {
            string lcampos = this.tbxCampos.Text;
            JArray campos = leerJson(lcampos);
            if (campos != null) 
            {
                this.jsonLeido = JArrayToString(campos);
                this.generado = generar(this.llave, campos);
                this.tbxCadenaCodificada.Text = "";
                this.mensaje = "Generacion Exitosa";
               
            } 
            else
            {
                this.mensaje = "Error en formato campos";
            }
        }

        protected void btnDecodificar_Click(object sender, EventArgs e)
        {
            string cadenaGenerada = this.tbxCadenaCodificada.Text;
            if (cadenaGenerada != "")
            {
                JwtSecurityToken sToken = null;
                string mensajeError = null;
                string lLlave = this.tbxCodigoSeguridad.Text;
                if (validarJwt(cadenaGenerada, lLlave, out sToken, out mensajeError))
                {
                    this.decodificado = tokenToString(sToken);
                    this.mensaje = "Decodificado exitoso!!";
                }
                else {
                    this.mensaje = "Error, token invalido: " + mensajeError;                
                    
                }
            }
            else {
                this.mensaje = "Error, ingrese cadena a decodificar";                
            }
            
        }


        protected JArray leerJson(string camposJson)
        {
            try
            {
                string lJson = camposJson;// "[{\"cufe\": \"43343\",\"ruc\": \"1111\"}]";
                var objects = JArray.Parse(lJson);
                return objects;
            }
            catch (Exception ex) {
                return null;
            }
        }

        protected string JArrayToString(JArray campos) {
            StringBuilder sb = new StringBuilder();
            foreach (JObject root in campos)
            {
                foreach (KeyValuePair<String, JToken> app in root)
                {
                    var llave = app.Key;
                    var valor = app.Value;
                    sb.Append(llave + ":" + valor + "-");
                }
            }
            return sb.ToString();
        }


        protected string tokenToString(JwtSecurityToken stoken)
        {

            StringBuilder sb = new StringBuilder();
            foreach (Claim claim in stoken.Claims)
            {
                sb.Append(claim.Type + " : " + claim.Value + " : ");// + claim.ValueType);
            }
            return sb.ToString();
        
        }

        protected bool validarJwt(string encodedJwt, string pLlave, out JwtSecurityToken jwtSTValido, out string mensajeError) {

            var tokenHandler = new JwtSecurityTokenHandler();

            var validationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                ValidateLifetime = false,
                ValidateAudience = false,
                ValidateIssuer = false,
                IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(
                System.Text.Encoding.Default.GetBytes(pLlave))
            };

            //var tokenS = tokenHandler.ReadToken(encodedJwt) as JwtSecurityToken;

            Microsoft.IdentityModel.Tokens.SecurityToken tokenS;
            try
            {
                tokenHandler.ValidateToken(encodedJwt, validationParameters, out tokenS);
                jwtSTValido = (JwtSecurityToken)tokenS;
                mensajeError = null;
                return true;
            }
            catch (Exception ex)
            {
                jwtSTValido = null;
                mensajeError = "Fallo la validación, la clave o el contenido no se pudo verificar.";
                return false;
            }
            //return  tokenS != null  ;

            
        }



        // Forma simple de generar un codigo de 128 caracteres
        protected string generarLlave()
        {
            string llave = Guid.NewGuid().ToString("n")
                + Guid.NewGuid().ToString("n")
                + Guid.NewGuid().ToString("n")
                + Guid.NewGuid().ToString("n");
            return llave;
            //return Guid.NewGuid().ToString("n").Substring(0, 128);
        }


    }


}